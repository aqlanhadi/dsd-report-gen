const serverless = require('serverless-http')
const express = require('express')
const app = express()

app.get('/', (req, res) => {
    res.send(`(c) ${new Date().getFullYear()} Digital Skills Development`)
})

module.exports.handler = serverless(app)